// Data klinis read-only untuk aplikasi pasien (hasil input perawat/peneliti).
const express = require("express");
const db = require("../db/database");
const auth = require("../middleware/auth");
const { parseMeasurement } = require("../services/clinical");

const router = express.Router();

router.get("/", auth, (req, res) => {
  const p = db.prepare("SELECT id, code, group_type, study_start, planned_sessions FROM participants WHERE user_id = ?").get(req.userId);
  if (!p) return res.json({ participant: null, measurements: [] });
  const measurements = db
    .prepare(
      `SELECT id, timepoint, measured_at, abi_left, abi_right, ntss6_total, dn4_total, nrs,
              skin_temp_left, skin_temp_right, lactate
       FROM measurements WHERE participant_id = ? ORDER BY measured_at`
    )
    .all(p.id)
    .map(parseMeasurement);
  res.json({ participant: p, measurements });
});

module.exports = router;
